jQuery(document).ready(function() {
	
	jQuery('#upload_image_button_thumb').click(function() {
		
		window.send_to_editor = function(html) 
		
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image_thumb').val(imgurl);
			tb_remove();
		}
	 
	 
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
 
	jQuery('#upload_image_button').click(function() {
		
		window.send_to_editor = function(html) 
		
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image').val(imgurl);
			tb_remove();
		}
	 
	 
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	 
	jQuery('#upload_image_button2').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image2').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button3').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image3').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button4').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image4').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button5').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image5').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button6').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image6').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button7').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image7').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button8').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image8').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button9').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image9').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});
	
	jQuery('#upload_image_button10').click(function() {
		
		window.send_to_editor = function(html) 
		{
			imgurl = jQuery('img',html).attr('src');
			jQuery('#upload_image10').val(imgurl);
			tb_remove();
		}
	
		tb_show('', 'media-upload.php?post_id=0&amp;type=image&amp;TB_iframe=true');
		return false;
		
	});

});
